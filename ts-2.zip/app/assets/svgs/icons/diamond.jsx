import React from "react";

const Diamond = () => (
    <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8.2085" y="0.00878906" width="12" height="12" rx="2" transform="rotate(45 8.2085 0.00878906)" fill="black" />
    </svg>

)

export {
    Diamond
}